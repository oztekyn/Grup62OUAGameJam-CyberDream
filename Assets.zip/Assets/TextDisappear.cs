using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class WritingCountdown : MonoBehaviour
{
    public TextMeshPro textMesh;

    private void Start()
    {
        StartCoroutine(DisableText());
    }

    private IEnumerator DisableText()
    {
        yield return new WaitForSeconds(3);
        textMesh.gameObject.SetActive(false);
    }
}
